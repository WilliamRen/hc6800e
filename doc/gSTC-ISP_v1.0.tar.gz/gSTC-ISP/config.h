/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* Define to 1 if your C compiler doesn't accept -c and -o together. */
/* #undef NO_MINUS_C_MINUS_O */

/* Name of package */
#define PACKAGE "gSTCISP"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "gSTCISP"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "gSTCISP 0.1"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "gstcisp"

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.1"

/* Version number of package */
#define VERSION "0.1"
